//
//  Pregunta.swift
//  P5_QuizAppIOS2018
//
//  Created by Luis Martin de Vidales Palomero on 22/11/2018.
//  Copyright © 2018 UPM. All rights reserved.
//

import UIKit

class Pregunta: PreguntaViewController {

}
